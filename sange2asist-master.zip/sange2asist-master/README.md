# DONE UPDATE 5_FEBRUARY_2018

# 1 selfbot 2 asist
V2.1 editor_::
Prankbots
# PRANKBOTS
![Prankbots](prankbots.png)
V2.1 last update::
05/0/2018
# CONTACT OFFICIAL

<a href="https://line.me/R/ti/p/%40gnh2780p"><img height="36" border="0" alt="Add Friend" src="https://scdn.line-apps.com/n/line_add_friends/btn/en.png"></a>

# LINE ME

[ADD_LINE](http://line.me/ti/p/~adiputra.95)

# TUTORIAL YOUTUBE
[LIHAT_DISINI](https://youtu.be/j9VqQBZCcec)

[@SUBCRABE](https://www.youtube.com/channel/UCycBrqSWEHdk-slnhUmGWiQ)

[BUAT AMBIL TOKKEN](http://101.255.95.249:6969)

## THANKS TO.
```=========
Allah swt
Prankbots
Black of gamer
Dan kawan-Kawan```
